import React, { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import { useVoiceStore } from '../../store/useVoiceStore';
import { voiceController } from '../../lib/voice/voiceController';
import { PhoneOff, Mic, MicOff, MessageSquare, Volume2, Sparkles, Brain, ArrowUpCircle } from 'lucide-react';
import { AudioWaveVisualizer } from './AudioWaveVisualizer';

interface VoiceCallOverlayProps {
  onClose: () => void;
}

export const VoiceCallOverlay: React.FC<VoiceCallOverlayProps> = ({ onClose }) => {
  const { userName } = useApp();
  const {
    voiceState,
    currentTranscript,
    lastBobReply,
    stopVoiceMode,
    interrupt,
    finishTurnImmediately,
    startPushToTalk,
    stopPushToTalk,
    isKokoroInstalled,
    openInstallCard,
  } = useVoiceStore();

  const [isMuted, setIsMuted] = useState(false);
  const [isAvatarHovered, setIsAvatarHovered] = useState(false);
  const [isSpaceHeld, setIsSpaceHeld] = useState(false);

  const isBobTurn = voiceState === 'SPEAKING' || voiceState === 'THINKING';
  const isUserTurn = voiceState === 'USER_SPEAKING' || voiceState === 'LISTENING';

  const handleEndCall = () => {
    stopVoiceMode();
    onClose();
  };

  const handleToggleMute = () => {
    if (isBobTurn) {
      interrupt();
    }
    setIsMuted(!isMuted);
  };

  // Immediate turn finalization on spacebar release or button click
  const handleDoneSpeaking = useCallback(async () => {
    if (voiceState === 'USER_SPEAKING' || voiceState === 'LISTENING') {
      await finishTurnImmediately();
    }
  }, [voiceState, finishTurnImmediately]);

  // Keyboard Spacebar Push-To-Talk
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !e.repeat) {
        // Prevent default page scroll
        e.preventDefault();
        setIsSpaceHeld(true);
        if (isBobTurn) {
          interrupt();
        }
        startPushToTalk('call');
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        setIsSpaceHeld(false);
        stopPushToTalk();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isBobTurn, interrupt, startPushToTalk, stopPushToTalk]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between p-6 sm:p-10 bg-neutral-950/92 backdrop-blur-2xl text-white select-none animate-in fade-in duration-300">
      {/* Top Status Header */}
      <div className="w-full max-w-2xl flex items-center justify-between pt-2">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
          <span className="text-[13px] font-bold tracking-wide uppercase text-neutral-400">
            Live Call with Bob
          </span>
          {voiceController.isLiveModeActive() ? (
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Gemini Live API
            </span>
          ) : (
            <span
              className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-[11px] font-semibold text-amber-300 flex items-center gap-1.5 cursor-help"
              title="Primary Gemini Live quota reached / network interruption. Switched to fallback agent mode."
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              Fallback Agent Mode
            </span>
          )}
          {isKokoroInstalled ? (
            <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-[11px] font-medium text-blue-300">
              Kokoro 82M ✓
            </span>
          ) : (
            <button
              onClick={() => openInstallCard('tts')}
              className="px-2.5 py-0.5 rounded-full bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-[11px] font-semibold text-amber-300 transition-colors cursor-pointer flex items-center gap-1"
              title="Download Kokoro 82M for near-human voice quality"
            >
              <span>Kokoro Voice</span>
              <span className="text-[9.5px] bg-amber-500/30 px-1 rounded uppercase">Get</span>
            </button>
          )}
        </div>

        <button
          onClick={handleEndCall}
          className="text-[12px] font-semibold text-neutral-400 hover:text-white px-3 py-1.5 rounded-xl hover:bg-neutral-900 border border-transparent hover:border-neutral-800 transition-all cursor-pointer"
        >
          Exit to text
        </button>
      </div>

      {/* Central Interactive Avatar Area */}
      <div className="flex flex-col items-center justify-center my-auto w-full max-w-lg space-y-8">
        {/* Dynamic Avatar Circle */}
        <div className="relative flex items-center justify-center">
          {/* Animated concentric audio reactive rings */}
          {voiceState === 'USER_SPEAKING' && (
            <>
              <div className="absolute w-52 h-52 rounded-full border border-amber-500/30 animate-ping [animation-duration:2s]" />
              <div className="absolute w-44 h-44 rounded-full bg-amber-500/10 blur-xl animate-pulse" />
            </>
          )}

          {voiceState === 'SPEAKING' && (
            <>
              <div className="absolute w-56 h-56 rounded-full border border-blue-500/30 animate-ping [animation-duration:2.5s]" />
              <div className="absolute w-48 h-48 rounded-full bg-blue-500/15 blur-xl animate-pulse" />
            </>
          )}

          {voiceState === 'THINKING' && (
            <div className="absolute w-48 h-48 rounded-full border-2 border-dashed border-amber-400/40 animate-spin [animation-duration:8s]" />
          )}

          {/* Main Avatar Button */}
          <button
            type="button"
            onMouseEnter={() => setIsAvatarHovered(true)}
            onMouseLeave={() => setIsAvatarHovered(false)}
            onClick={isAvatarHovered ? handleEndCall : isBobTurn ? interrupt : undefined}
            title={isAvatarHovered ? 'Click to End Call' : isBobTurn ? 'Bob speaking (click to interrupt)' : 'Voice active'}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl cursor-pointer relative z-10 ${
              isAvatarHovered
                ? 'bg-red-600 scale-105 ring-8 ring-red-500/30 shadow-[0_0_50px_rgba(220,38,38,0.6)]'
                : isBobTurn
                ? 'bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 ring-4 ring-blue-400/40 shadow-[0_0_45px_rgba(59,130,246,0.4)]'
                : 'bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 ring-4 ring-amber-400/30 shadow-[0_0_40px_rgba(245,158,11,0.35)]'
            }`}
          >
            {isAvatarHovered ? (
              <div className="flex flex-col items-center justify-center gap-1.5 animate-in zoom-in-95 duration-150">
                <PhoneOff className="w-8 h-8 text-white stroke-[2.2]" />
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-white">End Call</span>
              </div>
            ) : isBobTurn ? (
              <div className="flex flex-col items-center justify-center gap-1">
                <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-inner">
                  <Brain className="w-7 h-7 text-white animate-pulse" />
                </div>
                <span className="text-[12.5px] font-black tracking-wide text-white drop-shadow">Bob</span>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center gap-1">
                <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-[18px] font-extrabold text-white">
                  {(userName || 'A')[0].toUpperCase()}
                </div>
                <span className="text-[12px] font-bold text-white tracking-wide">
                  {userName || 'You'}
                </span>
              </div>
            )}
          </button>
        </div>

        {/* State Label */}
        <div className="flex flex-col items-center gap-2">
          <div className="px-4 py-1.5 rounded-full bg-neutral-900 border border-neutral-800 text-[12.5px] font-semibold flex items-center gap-2">
            {voiceState === 'LISTENING' && (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Listening... speak or hold Spacebar</span>
              </>
            )}
            {voiceState === 'USER_SPEAKING' && (
              <>
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                <span>{isSpaceHeld ? 'Recording speech (Hold Space)...' : 'Hearing you...'}</span>
              </>
            )}
            {voiceState === 'THINKING' && (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                <span>Bob is thinking...</span>
              </>
            )}
            {voiceState === 'SPEAKING' && (
              <>
                <Volume2 className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
                <span>Bob is replying... (talk to interrupt)</span>
              </>
            )}
          </div>

          <span className="text-[11px] text-neutral-400">
            {isBobTurn ? 'Bob is speaking (talk to interrupt anytime)' : 'Hold Spacebar to talk · Release or tap below to reply instantly'}
          </span>
        </div>

        {/* ChatGPT Style Real-time Audio Waveform */}
        <div className="w-full max-w-sm px-4 py-2 rounded-2xl bg-neutral-900/60 border border-neutral-800/80">
          <AudioWaveVisualizer
            active={voiceState === 'USER_SPEAKING' || voiceState === 'LISTENING'}
            color={isBobTurn ? '#60a5fa' : '#f59e0b'}
            height={32}
          />
        </div>

        {/* Immediate Send Now / Push-to-Talk action for noisy rooms */}
        {isUserTurn && (
          <button
            type="button"
            onClick={handleDoneSpeaking}
            title="Click when finished speaking to submit immediately without waiting for silence"
            className={`flex items-center gap-2 px-5 py-2 rounded-full font-bold text-[12px] transition-all cursor-pointer shadow-lg ${
              isSpaceHeld
                ? 'bg-amber-500 text-neutral-950 ring-4 ring-amber-400/50 scale-105'
                : 'bg-neutral-800/90 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 active:scale-95'
            }`}
          >
            <ArrowUpCircle className="w-4 h-4 text-emerald-400" />
            <span>{isSpaceHeld ? 'Listening (Release Space to send)' : 'Done Speaking · Reply Now'}</span>
            <kbd className="ml-1 text-[9.5px] px-1.5 py-0.5 rounded bg-black/40 text-neutral-400 font-mono">SPACE</kbd>
          </button>
        )}

        {/* Dynamic Speech & Transcript Cards */}
        <div className="w-full space-y-3 min-h-[110px] max-h-[220px] overflow-y-auto px-1">
          {/* User live speech card */}
          {currentTranscript.trim() && (
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-left animate-in fade-in duration-200">
              <div className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5 mb-1">
                <Mic className="w-3 h-3 text-amber-400" />
                <span>You said</span>
              </div>
              <p className="text-[13px] text-neutral-200 m-0 leading-relaxed font-medium">
                {currentTranscript}
              </p>
            </div>
          )}

          {/* Bob speech response card */}
          {lastBobReply && (
            <div className="p-3.5 rounded-2xl bg-blue-500/10 border border-blue-500/25 text-left animate-in fade-in duration-200">
              <div className="text-[11px] font-bold text-blue-400 flex items-center gap-1.5 mb-1">
                <Volume2 className="w-3 h-3 text-blue-400" />
                <span>Bob</span>
              </div>
              <p className="text-[13px] text-neutral-200 m-0 leading-relaxed">
                {lastBobReply}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Floating Call Control Bar */}
      <div className="w-full max-w-md pb-4 flex items-center justify-center gap-4">
        {/* Mute button */}
        <button
          onClick={handleToggleMute}
          title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer border ${
            isMuted
              ? 'bg-amber-500/20 border-amber-500 text-amber-400'
              : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800'
          }`}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Big End Call Button */}
        <button
          onClick={handleEndCall}
          title="End conversation"
          className="h-12 px-7 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold text-[13px] flex items-center gap-2.5 shadow-lg shadow-red-900/40 transition-all active:scale-95 cursor-pointer"
        >
          <PhoneOff className="w-4 h-4 stroke-[2.5]" />
          <span>End Call</span>
        </button>

        {/* Text Mode button */}
        <button
          onClick={handleEndCall}
          title="Switch back to message composer"
          className="w-12 h-12 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800 flex items-center justify-center transition-all cursor-pointer"
        >
          <MessageSquare className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export { AudioWaveVisualizer as VoiceWaveform } from './AudioWaveVisualizer';
