# Bob-Experience: Overlay Bubble, Proactive Companion & Sunflower Research Suite

A holistic upgrade to Bob transforming it into an organic, proactive companion: featuring an interactive overlay bubble with 10 daily life routines, intelligent speech engagement arcs, interest onboarding, interactive project roadmapping with lean clock scheduling, sequential task unlocking, unified minimal summary views, and the warm golden sunflower garden workspace.

***

### User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Decisions from Phase 1 Interview:**
> - **Routine Scheduling & Testing**: Real-time 24-hour clock synchronization paired with an interactive Time-Scrubber Dev Controller, enabling seamless testing and live previewing of Bob's 10 daily life states (cooking, reading, meditating, eating, sleeping, waking up).
> - **Voice & Audio Persona**: Interactive Web Speech synthesis with ambient harmonic chimes, ripple animations, and 45-second proactive green ring response cycles.
> - **Visual Atmosphere**: Warm golden sunlight, organic glassmorphism, blooming sunflower petals, and clean typography adhering to strict zero-pill discipline.

- **Sync Architecture**: Bidirectional state synchronization between the Desktop app and Chrome Side Panel for tabs, active research focus, and roadmap progress.
- **Pacing Mechanism**: Bob enforces a 3-message chat limit before gently prompting focus resumption, with an extended reminder at 10 turns.

***

### 1. Overview & Core Concept

- **What It Does**: Bob behaves as both an ambient companion and an intellectual co-pilot. When idle, Bob lives in a dynamic floating overlay bubble cycling through human daily routines (reading, meditating, cooking breakfast/lunch/supper, eating, listening to music, sleeping, waking up). When proactive triggers occur (idle on social media or focused for 20 minutes), Bob glows green to propose ideas. Inside the research studio, Bob guides users through a multi-step project roadmapping wizard, sequential task unlocking, time extension cards, and a unified executive summary.
- **Target Audience / Persona**: Knowledge workers, researchers, software developers, and students who juggle multi-tab browser sessions, AI chatbots (ChatGPT, Claude), and coding tools (Claude Code) and want an attentive, non-distracting assistant.
- **Key Value**: Replaces scattered research tabs with structured step-by-step roadmaps, eliminates context switching fatigue, and introduces life-like companion presence.

***

### 2. User Experience & Visual Design

#### A. The Floating Overlay Bubble & Daily Routines
- **Bubble Visuals**:
  - Circle avatar displaying high-fidelity loop states (Waking Up, Thinking, Listening, Speaking, Reading, Meditating, Cooking, Eating, Sleeping, Listening to Music).
  - **Outer Arc Ring**:
    - **Idle State**: Pristine white arc (`rgba(255, 255, 255, 0.85)`).
    - **Proactive Speech State**: Glowing emerald ring (`#22c55e`) pulsing for **45 seconds**. If clicked, Bob speaks and opens interaction. If ignored, Bob preserves the message in his memory inbox and softly reverts the arc to white.
- **Hover Quick-Pill**:
  - Hovering reveals a sleek floating glass pill with three actions:
    1. **`Chat`**: Opens general conversational companion mode (sports banter, breaking news, casual friendly check-in).
    2. **`Research`**: Attaches directly to the active research session open in the side panel or desktop.
    3. **`Side Panel`**: Quick-toggle to open or focus the side panel workspace.
- **Companion Routines Schedule (24-Hour Cycle & Time Scrubber)**:
  - `07:00 - 07:29`: Breakfast Eating & mindful connection to food.
  - `07:30 - 09:59`: Morning Meditation after breakfast.
  - `10:00 - 11:50`: Reading a book & mid-morning reflection.
  - `11:51 - 12:30`: Cooking lunch (1.5-hour food prep cycle).
  - `12:31 - 13:30`: Lunch Eating & pause.
  - `14:00 - 17:00`: Mid-afternoon Music & deep study listening.
  - `19:30 - 20:00`: Cooking supper (evening comfort food).
  - `20:01 - 21:00`: Supper Eating & wind-down.
  - `21:01 - 22:00`: Evening Meditation.
  - `22:00 - 06:59`: Sleeping & restorative sleep loop.
  - `First App Open / Wake Trigger`: Waking up animation warming up local AI & audio resources.
- **Proactive Intervention & Chat Pacing**:
  - **Social Media Drift**: After 5 minutes of idle/social browsing, Bob pings with friendly conversation.
  - **Deep Focus Lock-in**: After 15–20 minutes on a research tab, Bob delivers dual conversational messages: *"Seems like you've locked in today."* followed by *"What's that worth your full attention buddy?"*.
  - **Focus Redirect**: After 3 consecutive chat messages, Bob offers: *"Want to keep chatting, or jump back into [Project Name]?"*. If user continues, Bob re-prompts after 10 turns.
- **Interests Onboarding Card**:
  - Interactive popup card discovering user passions (Football, Basketball, AI Tech, Indie Music, Science, Space).
  - Includes interactive chip selectors and a custom input box (`"Add your custom passion..."`).

#### B. Sunflower Garden Home & Dashboard
- **Visual Atmosphere**: Luminous sunflower field with morning golden hour and night twilight modes, organic glassmorphic cards (`backdrop-blur-md bg-white/70 dark:bg-black/50 border border-white/20`), and subtle warm lighting.
- **Central Composer**: Floating search & inquiry bar with audio waveform trigger, quick prompt chips, and study orchestrator.
- **Home Cards**:
  1. **`Today's Focus`**: Directly calculated from open tasks, due-soon deadlines, and active project priority, featuring a quick `"Set Focus"` button.
  2. **`Recent Projects`**: Clean minimal project summaries with status dots and source counters.

#### C. Research Roadmapping Wizard
- **Step 1: Goal Definition**: Identify core project mission with guided starter prompts.
- **Step 2: Tool Selection**: Pre-populated tools (ChatGPT, Claude, Claude Code, YouTube, Documentation) + custom input box.
- **Step 3: Constraints**: Suggested constraints (Time, Budget, API limits, No-cloud privacy) + custom input field.
- **Step 4: Deadlines & Lean Clock**: Preset intervals + calendar date picker + an interactive radial **Lean Clock** popup for hour and minute scheduling.
- **Step 5: Interactive Roadmap Approval**: Proposes phased breakdown with collapsible tasks, drag-or-button reordering, priority re-ranking, and Bob's smart recommendations.

#### D. Sequential Task Execution & Unlock Gate
- **Step-by-Step Task Cards**:
  - Step 1: Resource video/link (e.g., YouTube tutorials with direct open icon).
  - Step 2: Formulated AI prompts (ChatGPT/Claude) with one-click copy buttons.
  - Step 3: Coding tool terminal instructions (Claude Code execution guide).
- **Sequential Unlocking**:
  - Steps for Task 1 are unlocked; Task 2 remains locked until the user confirms completion of Task 1.
  - Unlocking triggers a confirmation modal with `"Mark All Completed"` -> celebratory transition unlocking Task 2.
- **Pacing & "Need More Time?"**:
  - Estimated duration badges.
  - If elapsed time exceeds estimate, a polite card appears: *"Need more time?"* with 15m, 30m, 1h, 2h pills, plus *"Or are you feeling stuck somewhere? [Yes / No]"*.
  - Selecting "Yes" opens Bob's contextual synthesis to untangle the blockage using open tabs.

#### E. Minimalist Summary & Unified Tabs View
- **Summary Page (Desktop & Side Panel Sync)**:
  - High-clarity executive brief.
  - Quotes with distinct colored vertical indicator bars (`emerald`, `amber`, `sky`).
  - Key findings with evidence links.
  - Supporting sources with green relevance rating tags.
  - Recommended next steps strictly aligned with the Tasks roadmap.
- **Tabs Page**:
  - High-priority tabs opened today with confidence percentages.
  - Collapsible historical/other tabs archive.
  - Side panel selection mechanism that instantly syncs focused tabs to the Desktop workspace.

***

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Real-Time Schedule Engine with Dev Time Scrubber**:
  - *Chosen Approach*: The routine engine computes current routine based on local system time `new Date()`, while providing a floating preview scrubber in development mode allowing the user to scrub from 00:00 to 23:59 to inspect all 10 states instantly.
  - *Why*: Eliminates waiting hours to verify routine transitions while maintaining natural real-world behavior.
- **Decision 2: Audio & Speech Architecture**:
  - *Chosen Approach*: Web Speech API with synthesizer fallback, paired with Web Audio API chime generator for incoming proactive prompts.
  - *Why*: Zero external network dependencies, instant speech rendering, and lightweight memory footprint.
- **Decision 3: Zero-Pill Typography on Metadata**:
  - *Chosen Approach*: In accordance with frontend design standards, metadata and tags use clean unboxed text separated by typographic middots (`·`), reserving bordered containers strictly for clickable interactive filter controls.

***

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        AppShell & Window Header                        │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
       ┌────────────────────────────┼───────────────────────────┐
       ▼                            ▼                           ▼
┌──────────────┐             ┌──────────────┐            ┌──────────────┐
│  Side Panel  │ ◄──────────►│  Main App    │◄──────────►│ Bob Overlay  │
│  (Chrome     │  Shared     │  (Sunflower  │  Overlay   │  Bubble      │
│   Companion) │  Bridge     │   Garden)    │  Engine    │  (10 States) │
└──────┬───────┘             └──────┬───────┘            └──────┬───────┘
       │                            │                           │
       ├─ Tabs Sync                 ├─ Composer / Focus         ├─ Proactive Arc
       ├─ Highlight Stream          ├─ Roadmapping Wizard       ├─ Daily Routine
       └─ Summary View              └─ Sequential Tasks         └─ Chat/Research
                                                                   Pill Switch
```

#### Component & State Structure:
1. **`BobOverlayBubble.tsx`**:
   - Floating draggable bubble with 10 visual state loops (SVG & CSS particle animation).
   - Proactive emerald ring with 45s timeout countdown.
   - Hover pill with `Chat`, `Research`, and `Side Panel` navigation.
   - Pacing tracker (counts user messages, handles 3-message and 10-message focus prompts).
2. **`BobRoutineEngine.ts`**:
   - Calculates active routine based on hour/minute:
     - 07:00–07:29: Eating (Breakfast)
     - 07:30–09:59: Meditating
     - 10:00–11:50: Reading a book
     - 11:51–12:30: Cooking (Lunch)
     - 12:31–13:30: Eating (Lunch)
     - 14:00–17:00: Listening to music
     - 19:30–20:00: Cooking (Supper)
     - 20:01–21:00: Eating (Supper)
     - 21:01–22:00: Meditating
     - 22:00–06:59: Sleeping
     - Wake trigger: Waking up
   - Emits routine transitions, custom breakfast/lunch/dinner commentary, and audio chimes.
3. **`UserInterestsModal.tsx`**:
   - Interactive profile card for sports, teams, celebrities, and custom interests.
4. **`RoadmapWizardModal.tsx` & `LeanClockPicker.tsx`**:
   - 5-step interactive roadmapping cards with priority reordering and analog-digital lean clock.
5. **`TasksView.tsx` & `TaskUnlockModal.tsx`**:
   - Sequential lock/unlock gates, step-by-step external tool cards (YouTube, ChatGPT, Claude Code), and time-extension prompts.
6. **`SummaryView.tsx` & `TabsView.tsx`**:
   - Synchronized between desktop and side panel with quotes, colored bars, and priority tab selection.
