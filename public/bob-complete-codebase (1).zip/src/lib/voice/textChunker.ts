// Sentence chunker from Bob Voice Engine spec (B6 & B8)
// Short first chunk = faster first audio. Abbreviation-safe, max 220 chars.

const ABBR = new Set(['mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'vs', 'etc', 'e.g', 'i.e', 'st', 'u.s', 'no']);
const END_REGEX = /[.!?…]+["')\]]*\s/g;
const CLAUSE_REGEX = /[,;:—–]\s/g;

export function cleanTextForSpeech(t: string): string {
  if (!t) return '';
  return t
    .replace(/```.*?```/gs, ' ')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/https?:\/\/\S+/g, '')
    .replace(/[`*_#>~|]+/g, '')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
    .replace(/\{[\s\S]*?\}/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export class ResponseTextChunker {
  private buf = '';
  private first = true;
  private firstMin = 28;
  private minChars = 24;
  private firstClauseMin = 38;
  private maxChars = 220;
  private onChunkReady: (chunk: string) => void;

  constructor(onChunkReady: (chunk: string) => void) {
    this.onChunkReady = onChunkReady;
  }

  private nextCut(s: string): number | null {
    const floor = this.first ? this.firstMin : this.minChars;
    END_REGEX.lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = END_REGEX.exec(s)) !== null) {
      const words = s.slice(0, match.index).trim().split(/\s+/);
      const lastWord = words[words.length - 1]?.toLowerCase().replace(/\.+$/, '') || '';
      if (ABBR.has(lastWord) || (lastWord.length === 1 && /^[a-z]$/i.test(lastWord))) {
        continue;
      }
      const endPos = match.index + match[0].length;
      if (endPos >= floor) {
        return endPos;
      }
    }

    if (this.first) {
      CLAUSE_REGEX.lastIndex = 0;
      while ((match = CLAUSE_REGEX.exec(s)) !== null) {
        const endPos = match.index + match[0].length;
        if (endPos >= this.firstClauseMin) {
          return endPos;
        }
      }
    }

    if (s.length > this.maxChars) {
      const cut = s.lastIndexOf(' ', this.maxChars);
      return cut > 0 ? cut + 1 : this.maxChars;
    }

    return null;
  }

  public feed(token: string): void {
    this.buf += token;
    let cut: number | null;
    while ((cut = this.nextCut(this.buf)) !== null) {
      const piece = this.buf.slice(0, cut).trim();
      this.buf = this.buf.slice(cut);
      if (piece) {
        const cleaned = cleanTextForSpeech(piece);
        if (cleaned) {
          this.onChunkReady(cleaned);
          this.first = false;
        }
      }
    }
  }

  public flush(): void {
    const piece = this.buf.trim();
    this.buf = '';
    if (piece) {
      const cleaned = cleanTextForSpeech(piece);
      if (cleaned) {
        this.onChunkReady(cleaned);
      }
    }
  }

  public reset(): void {
    this.buf = '';
    this.first = true;
  }
}
