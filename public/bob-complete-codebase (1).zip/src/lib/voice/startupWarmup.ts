// Bob Voice Engine — Boot-Time Warmup (spec B1 & B10)
// Compiles and pre-warms STT & TTS models during startup so the first speech turn
// has ZERO cold-start JIT inference latency.

import { localVoiceManager } from './localVoiceManager';
import { tts } from './ttsProvider';

let isWarmupRunning = false;
let isWarmupComplete = false;

export async function warmupVoiceEngine(): Promise<void> {
  if (typeof window === 'undefined') return;
  if (isWarmupRunning || isWarmupComplete) return;

  isWarmupRunning = true;

  try {
    // 1. Pre-warm STT (Whisper Tiny) if installed or cached
    if (localVoiceManager.isModelInstalled()) {
      const ready = await localVoiceManager.ensureReady();
      if (ready) {
        // Run dummy 0.2s silent inference to warm up WASM / WebGPU tensor pipelines
        const dummySamples = new Float32Array(3200);
        await localVoiceManager.transcribeSamples(dummySamples);
        console.log('[StartupWarmup] STT pipeline pre-warmed & ready.');
      }
    }

    // 2. Pre-warm Kokoro TTS if installed or cached
    if (tts.isKokoroInstalled()) {
      await tts.initKokoro();
      console.log('[StartupWarmup] Kokoro 82M TTS pre-warmed & ready.');
    }

    isWarmupComplete = true;
  } catch (err) {
    console.warn('[StartupWarmup] Background model warm-up notice:', err);
  } finally {
    isWarmupRunning = false;
  }
}

export function isEngineWarmedUp(): boolean {
  return isWarmupComplete;
}
