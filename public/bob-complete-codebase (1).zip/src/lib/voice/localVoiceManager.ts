// Bob Local Voice Model Manager
// Provides 100% free, on-device, offline-capable Speech-to-Text via @huggingface/transformers
// Supports Moonshine Tiny (~35MB, ultra-low latency real-time) and Whisper Tiny (~39MB).
// Runs on device: 'cpu' or 'webgpu' (never crashes on 'wasm').

export type SttModelChoice = 'moonshine-tiny' | 'whisper-tiny';

export interface SttModelInfo {
  id: SttModelChoice;
  name: string;
  repo: string;
  sizeMb: number;
  description: string;
}

export const STT_MODELS: Record<SttModelChoice, SttModelInfo> = {
  'moonshine-tiny': {
    id: 'moonshine-tiny',
    name: 'Moonshine Tiny',
    repo: 'onnx-community/Moonshine-Tiny-ONNX',
    sizeMb: 35,
    description: 'Ultra-low latency real-time edge ASR. Designed for phone-speed live conversation and fast dictation.'
  },
  'whisper-tiny': {
    id: 'whisper-tiny',
    name: 'Whisper Tiny (Quantized)',
    repo: 'onnx-community/whisper-tiny.en',
    sizeMb: 39,
    description: 'Robust OpenAI Whisper architecture. High accuracy on diverse accents, background noise, and punctuation.'
  }
};

export interface ModelDownloadProgress {
  status: 'idle' | 'downloading' | 'ready' | 'error';
  progress: number; // 0 to 100
  bytesLoaded: number;
  bytesTotal: number;
  fileName: string;
  modelId: SttModelChoice;
  error?: string;
}

type ProgressListener = (status: ModelDownloadProgress) => void;

class LocalVoiceManager {
  private transcriber: any = null;
  private isDownloading = false;
  private currentModelId: SttModelChoice = 'whisper-tiny';
  private listeners: Set<ProgressListener> = new Set();
  private currentProgress: ModelDownloadProgress = {
    status: 'idle',
    progress: 0,
    bytesLoaded: 0,
    bytesTotal: 0,
    fileName: '',
    modelId: 'whisper-tiny'
  };

  constructor() {
    if (typeof window !== 'undefined') {
      const savedModel = localStorage.getItem('bob_selected_stt_model') as SttModelChoice;
      if (savedModel && STT_MODELS[savedModel]) {
        this.currentModelId = savedModel;
      }
      this.currentProgress.modelId = this.currentModelId;
      this.checkIfAlreadyInstalled();
    }
  }

  private checkIfAlreadyInstalled() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(`bob_local_${this.currentModelId}_ready`);
      if (saved === 'true') {
        this.warmupIfCached();
      }
    }
  }

  private async warmupIfCached() {
    if (this.transcriber || this.isDownloading) return;
    try {
      await this.downloadModel(true, this.currentModelId);
    } catch {
      // Quiet on background warmup
    }
  }

  public getSelectedModel(): SttModelChoice {
    return this.currentModelId;
  }

  public setSelectedModel(modelId: SttModelChoice): void {
    if (STT_MODELS[modelId]) {
      this.currentModelId = modelId;
      this.currentProgress.modelId = modelId;
      if (typeof window !== 'undefined') {
        localStorage.setItem('bob_selected_stt_model', modelId);
      }
      // If switching models, unload current transcriber so new one is loaded
      this.transcriber = null;
      this.emit({ status: this.isModelInstalled() ? 'ready' : 'idle', modelId });
    }
  }

  public subscribe(listener: ProgressListener): () => void {
    this.listeners.add(listener);
    listener(this.currentProgress);
    return () => this.listeners.delete(listener);
  }

  private emit(progress: Partial<ModelDownloadProgress>) {
    this.currentProgress = { ...this.currentProgress, ...progress };
    this.listeners.forEach((fn) => fn(this.currentProgress));
  }

  public getStatus(): ModelDownloadProgress {
    return this.currentProgress;
  }

  public isReady(): boolean {
    return Boolean(this.transcriber);
  }

  public isModelInstalled(modelId?: SttModelChoice): boolean {
    const target = modelId || this.currentModelId;
    if (this.isReady() && this.currentModelId === target) return true;
    if (typeof window !== 'undefined') {
      return (
        localStorage.getItem(`bob_local_${target}_ready`) === 'true' ||
        localStorage.getItem('bob_local_whisper_ready') === 'true'
      );
    }
    return false;
  }

  public async ensureReady(modelId?: SttModelChoice): Promise<boolean> {
    const target = modelId || this.currentModelId;
    if (this.isReady() && this.currentModelId === target) return true;
    return await this.downloadModel(false, target);
  }

  /**
   * Downloads and initializes the selected local model.
   * Uses device: 'cpu' or 'webgpu' (never 'wasm' which crashes).
   */
  public async downloadModel(silent = false, targetModelId?: SttModelChoice): Promise<boolean> {
    const modelChoice = targetModelId || this.currentModelId;
    this.currentModelId = modelChoice;
    const modelInfo = STT_MODELS[modelChoice];

    if (this.transcriber && this.currentModelId === modelChoice) {
      this.emit({ status: 'ready', progress: 100, modelId: modelChoice });
      return true;
    }
    if (this.isDownloading) return false;

    this.isDownloading = true;
    if (!silent) {
      this.emit({
        status: 'downloading',
        progress: 0,
        bytesLoaded: 0,
        bytesTotal: 0,
        fileName: `Initializing ${modelInfo.name}…`,
        modelId: modelChoice
      });
    }

    try {
      const { pipeline, env } = await import('@huggingface/transformers');
      if (typeof window !== 'undefined') {
        env.allowLocalModels = false;
        env.useBrowserCache = true;
      }

      const fileProgressMap = new Map<string, { loaded: number; total: number }>();

      // Safe device selection: 'webgpu' if GPU available, otherwise 'cpu' (WASM runtime)
      const selectedDevice =
        typeof navigator !== 'undefined' && (navigator as any).gpu ? 'webgpu' : 'cpu';

      const pipelineOptions: any = {
        device: selectedDevice,
        progress_callback: (item: any) => {
          if (silent) return;

          if (item.status === 'progress' && item.file) {
            fileProgressMap.set(item.file, {
              loaded: item.loaded || 0,
              total: item.total || 0
            });

            let totalLoaded = 0;
            let totalBytes = 0;
            fileProgressMap.forEach((val) => {
              totalLoaded += val.loaded;
              totalBytes += val.total;
            });

            const percent =
              totalBytes > 0
                ? Math.min(99, Math.round((totalLoaded / totalBytes) * 100))
                : item.progress || 0;

            this.emit({
              status: 'downloading',
              progress: percent,
              bytesLoaded: totalLoaded,
              bytesTotal: totalBytes,
              fileName: item.file.split('/').pop() || item.file,
              modelId: modelChoice
            });
          } else if (item.status === 'done' && !silent) {
            this.emit({
              fileName: `Loaded ${item.file.split('/').pop() || ''}`,
              modelId: modelChoice
            });
          }
        }
      };

      if (modelChoice === 'whisper-tiny') {
        pipelineOptions.dtype = 'q8';
      }

      this.transcriber = await pipeline(
        'automatic-speech-recognition',
        modelInfo.repo,
        pipelineOptions
      );

      this.isDownloading = false;
      this.emit({
        status: 'ready',
        progress: 100,
        fileName: `${modelInfo.name} Active (100% Offline)`,
        modelId: modelChoice
      });

      if (typeof window !== 'undefined') {
        localStorage.setItem(`bob_local_${modelChoice}_ready`, 'true');
        localStorage.setItem('bob_local_whisper_ready', 'true');
      }
      return true;
    } catch (err: any) {
      this.isDownloading = false;
      console.warn('[LocalVoiceManager] Model download error:', err);
      if (!silent) {
        this.emit({
          status: 'error',
          error: err?.message || 'Could not load speech model. Check network.',
          modelId: modelChoice
        });
      }
      return false;
    }
  }

  /**
   * Directly transcribes a 16kHz Float32Array PCM buffer.
   * Completely bypasses container/codec issues.
   */
  public async transcribeSamples(samples: Float32Array): Promise<string> {
    if (!this.transcriber || !samples || samples.length === 0) {
      return '';
    }

    try {
      // Must have at least 0.2 seconds of audio (~3200 samples at 16kHz)
      if (samples.length < 3200) return '';

      // Check audio energy: if absolute silence, skip inference
      let maxAmp = 0;
      for (let i = 0; i < samples.length; i++) {
        const abs = Math.abs(samples[i]);
        if (abs > maxAmp) maxAmp = abs;
      }
      if (maxAmp < 0.005) {
        return '';
      }

      const output = await this.transcriber(samples);
      const text =
        typeof output === 'string'
          ? output.trim()
          : output?.text
          ? output.text.trim()
          : Array.isArray(output) && output[0]?.text
          ? output[0].text.trim()
          : '';

      // Filter hallucinated tokens like [BLANK_AUDIO] or (music)
      if (/^(\[|\().*(\]|\))$/.test(text)) {
        return '';
      }
      return text;
    } catch (e: any) {
      console.warn('[LocalVoiceManager] Sample transcription error:', e);
      return '';
    }
  }

  public clearModel(): void {
    this.transcriber = null;
    this.currentProgress = {
      status: 'idle',
      progress: 0,
      bytesLoaded: 0,
      bytesTotal: 0,
      fileName: '',
      modelId: this.currentModelId
    };
    if (typeof window !== 'undefined') {
      localStorage.removeItem(`bob_local_${this.currentModelId}_ready`);
      localStorage.removeItem('bob_local_whisper_ready');
    }
    this.emit(this.currentProgress);
  }
}

export const localVoiceManager = new LocalVoiceManager();
