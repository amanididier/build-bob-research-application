import { DEFAULT_VOICE_CONFIG } from './voiceConfig';

export interface VADCallbacks {
  onSpeechStart: () => void;
  onSpeechEnd: () => void;
  onEnergyChange?: (energy: number) => void;
}

export interface VADProvider {
  start: (stream: MediaStream, callbacks: VADCallbacks, silenceDurationMs?: number) => void;
  stop: () => void;
}

export class VoiceActivityDetector implements VADProvider {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private rafId: number | null = null;
  private isSpeaking = false;
  private speechStartTime = 0;
  private lastSpeechTime = 0;
  private silenceTimer: any = null;
  private isRunning = false;

  public start(stream: MediaStream, callbacks: VADCallbacks, customSilenceMs?: number): void {
    if (this.isRunning) return;

    const silenceMs = customSilenceMs || DEFAULT_VOICE_CONFIG.speechEndSilenceDurationMs || 1500;

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioCtx();
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 512;
      this.analyser.smoothingTimeConstant = 0.2;

      this.sourceNode = this.audioContext.createMediaStreamSource(stream);
      this.sourceNode.connect(this.analyser);

      this.isRunning = true;
      const buffer = new Uint8Array(this.analyser.frequencyBinCount);
      let noiseFloor = 12;
      let peakSpeechEnergy = 20;

      const loop = () => {
        if (!this.isRunning || !this.analyser) return;

        this.analyser.getByteFrequencyData(buffer);
        let sum = 0;
        for (let i = 0; i < buffer.length; i++) {
          sum += buffer[i];
        }
        const energy = sum / buffer.length; // 0 to 255
        callbacks.onEnergyChange?.(energy);

        const now = Date.now();

        // Dynamically calibrate background noise floor
        if (!this.isSpeaking) {
          noiseFloor = noiseFloor * 0.95 + energy * 0.05;
        } else {
          if (energy > peakSpeechEnergy) {
            peakSpeechEnergy = energy;
          }
        }

        // Adaptive threshold: at least 10 above ambient noise floor, minimum 14
        const adaptiveThreshold = Math.max(noiseFloor + 10, DEFAULT_VOICE_CONFIG.speechStartThreshold || 14);
        // Silence condition: energy falls below adaptive threshold OR drops to less than half peak speech
        const isQuiet = energy < adaptiveThreshold || (this.isSpeaking && energy < peakSpeechEnergy * 0.42);

        if (!isQuiet) {
          if (!this.isSpeaking) {
            this.isSpeaking = true;
            this.speechStartTime = now;
            peakSpeechEnergy = energy;
            callbacks.onSpeechStart();
          }
          this.lastSpeechTime = now;
          if (this.silenceTimer) {
            clearTimeout(this.silenceTimer);
            this.silenceTimer = null;
          }

          // Safety utterance cap: if user has spoken continuously for 8.5 seconds, force speech end
          if (now - this.speechStartTime > 8500) {
            this.isSpeaking = false;
            callbacks.onSpeechEnd();
            return;
          }
        } else if (this.isSpeaking) {
          // In silence window
          const speechDuration = now - this.speechStartTime;
          if (!this.silenceTimer && speechDuration >= (DEFAULT_VOICE_CONFIG.minimumSpeechDurationMs || 300)) {
            this.silenceTimer = setTimeout(() => {
              if (this.isSpeaking) {
                this.isSpeaking = false;
                callbacks.onSpeechEnd();
              }
              this.silenceTimer = null;
            }, silenceMs);
          }
        }

        this.rafId = requestAnimationFrame(loop);
      };

      this.rafId = requestAnimationFrame(loop);
    } catch (err) {
      console.warn('VAD initialization failed:', err);
    }
  }

  public stop(): void {
    this.isRunning = false;
    this.isSpeaking = false;

    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }

    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }

    if (this.analyser) {
      try {
        this.analyser.disconnect();
      } catch {}
      this.analyser = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }
  }
}

export const vad = new VoiceActivityDetector();
