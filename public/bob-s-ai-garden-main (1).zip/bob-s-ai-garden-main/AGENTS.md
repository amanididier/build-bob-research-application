<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep Dashboard, Summary, and Tasks in focused workspace components with shared in-memory state; this is a presentation prototype, not a connection to the external Bob app.
- Scope workspace light/dark tokens to `.workspace` so refinements do not alter the preserved launch page at `/download`.
