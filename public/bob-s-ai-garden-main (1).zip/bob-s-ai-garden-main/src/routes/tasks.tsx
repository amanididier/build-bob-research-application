import { createFileRoute } from '@tanstack/react-router';
import { Tasks } from '@/components/workspace/tasks';
export const Route = createFileRoute('/tasks')({
  head: () => ({ meta: [
    { title: 'Tasks · Bob Research Companion' },
    { name: 'description', content: 'Keep your research moving with a focused task list, project roadmap, and clear next steps.' },
    { property: 'og:title', content: 'Tasks · Bob Research Companion' },
    { property: 'og:description', content: 'Less on your mind. More moving forward with Bob.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ] }), component: Tasks,
});
