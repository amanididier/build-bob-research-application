import { createFileRoute } from '@tanstack/react-router';
import { Dashboard } from '@/components/workspace/dashboard';
export const Route = createFileRoute('/')({
  head: () => ({ meta: [
    { title: 'Dashboard · Bob Research Companion' },
    { name: 'description', content: 'A calm workspace for your research, projects, goals, and daily progress with Bob.' },
    { property: 'og:title', content: 'Dashboard · Bob Research Companion' },
    { property: 'og:description', content: 'Your ideas are going places. See your projects, progress, and next steps.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ] }), component: Dashboard,
});
