import { createFileRoute } from '@tanstack/react-router';
import { Summary } from '@/components/workspace/summary';
export const Route = createFileRoute('/summary')({
  head: () => ({ meta: [
    { title: 'Summary · Bob Research Companion' },
    { name: 'description', content: 'The important ideas, open questions, and next moves in your Bob research workspace.' },
    { property: 'og:title', content: 'Summary · Bob Research Companion' },
    { property: 'og:description', content: 'A clear working brief of your research and where to go next.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ] }), component: Summary,
});
