import { createFileRoute } from "@tanstack/react-router";
import { Download, Chrome, LogIn, ArrowRight, Brain, Search, Puzzle, Check } from "lucide-react";
import logo from "@/assets/bob-logo.png.asset.json";
import garden from "@/assets/sunflower-garden.png.asset.json";
import extensionZip from "@/assets/bob-chrome-extension.zip.asset.json";

const WEB_APP = "https://d-bob-research-application.vercel.app";
const WINDOWS_DOWNLOAD =
  "https://github.com/amanididier/build-bob-research-application/releases/latest/download/Bob-Research-Companion-Setup.exe";

export const Route = createFileRoute("/download")({
  head: () => ({
    meta: [
      { title: "Bob — your AI research friend" },
      { name: "description", content: "Download Bob, the AI research companion that remembers your goals and thinks deeply with you. Free for early users." },
      { property: "og:title", content: "Bob — your AI research friend" },
      { property: "og:description", content: "Download Bob for Windows or add the Chrome extension. Free for the first users." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Btn({ href, children, tone = "green", download }: { href: string; children: React.ReactNode; tone?: "green" | "sun" | "bow" | "white"; download?: string }) {
  const tones = {
    green: "bg-primary text-primary-foreground [--btn-shadow:var(--primary-shadow)]",
    sun: "bg-sun text-foreground [--btn-shadow:var(--sun-shadow)]",
    bow: "bg-bow text-accent-foreground [--btn-shadow:var(--bow-shadow)]",
    white: "bg-card text-foreground border border-border [--btn-shadow:var(--border)]",
  };
  return (
    <a href={href} download={download} className={`btn-3d inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full px-6 py-3.5 text-base font-semibold ${tones[tone]}`}>
      {children}
    </a>
  );
}

const features = [
  { icon: Brain, title: "Remembers you", text: "Bob keeps your goals, tone and past research, so every session picks up where you left off.", color: "bg-sun text-choco" },
  { icon: Search, title: "Deep research", text: "Connects your sources and reasons over them for clear, cited answers.", color: "bg-bow text-card" },
  { icon: Puzzle, title: "Lives in your browser", text: "The Chrome extension sends tabs and highlights straight to Bob.", color: "bg-primary text-card" },
];

function Index() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-background font-sans text-foreground antialiased">
      <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
          <a href="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Bob logo" className="h-8 w-8" />
            <span className="text-lg font-bold tracking-tight">Bob</span>
          </a>
          <nav className="flex items-center gap-1 text-sm font-medium">
            <a href="#download" className="hidden rounded-full px-4 py-2 text-muted-foreground hover:text-foreground sm:inline-block">Download</a>
            <a href={`${WEB_APP}/sign-in`} className="rounded-full px-4 py-2 text-muted-foreground hover:text-foreground">Log in</a>
            <a href={`${WEB_APP}/sign-up`} className="rounded-full bg-foreground px-4 py-2 text-background">Sign up</a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 pb-24 pt-16 text-center md:pt-24">
        <div className="relative mx-auto w-fit">
          <img src={logo.url} alt="Bob, a smiling yellow triangle with a blue bow tie" className="animate-bob mx-auto h-44 w-44 md:h-56 md:w-56" />
          <div className="absolute -right-24 top-2 rotate-6 rounded-2xl rounded-bl-sm border-4 border-card bg-bow px-4 py-2 text-left text-sm font-bold text-card shadow-lg md:-right-36 md:text-base">
            Hi there!<br /><span className="font-medium opacity-90">I'm Bob.</span>
          </div>
        </div>
        <h1 className="mx-auto mt-10 max-w-3xl text-5xl font-extrabold tracking-tight md:text-7xl">
          Your friendly <span className="text-bow">AI research</span> <span className="relative inline-block"><span className="relative z-10">companion.</span><span className="absolute inset-x-0 bottom-1 -z-0 h-4 rounded bg-sun md:h-5" /></span>
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground md:text-xl">
          Save sources, keep your goals in memory and get deep, thoughtful answers — all in one cheerful place.
        </p>
        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Btn href={WINDOWS_DOWNLOAD}><Download className="h-5 w-5" /> Download for free</Btn>
          <Btn href={`${WEB_APP}/sign-up`} tone="white">Try on the web <ArrowRight className="h-4 w-4" /></Btn>
        </div>
        <p className="mt-4 text-sm text-muted-foreground">Windows · Chrome extension · Web</p>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid gap-5 md:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="rounded-3xl bg-muted p-8 transition-transform hover:-translate-y-1">
              <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${f.color}`}>
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-6 text-xl font-semibold tracking-tight">{f.title}</h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Sunflower garden */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="relative overflow-hidden rounded-[2rem]">
          <img src={garden.url} alt="Sunflower garden under a blue sky" className="h-[26rem] w-full object-cover" loading="lazy" />
          <div className="absolute inset-x-0 top-0 p-10 text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-5xl">A home that feels like sunshine.</h2>
            <p className="mx-auto mt-3 max-w-md font-medium text-foreground/70">Bob greets you in a calm sunflower garden, ready to dig in.</p>
          </div>
        </div>
      </section>

      {/* Early access */}
      <section id="download" className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid items-center gap-10 overflow-hidden rounded-[2rem] bg-choco p-10 text-card md:grid-cols-[1.3fr_1fr] md:p-16">
          <div>
            <span className="inline-block rounded-full bg-primary px-3 py-1 text-xs font-bold uppercase tracking-wider">Early access</span>
            <h2 className="mt-5 text-4xl font-extrabold tracking-tight md:text-5xl">Be one of the first to meet Bob.</h2>
            <p className="mt-4 max-w-md text-lg opacity-80">Download today and try everything free as one of our first users.</p>
            <ul className="mt-6 space-y-2">
              {["Free for early users", "All features unlocked", "Shape what Bob learns next"].map((t) => (
                <li key={t} className="flex items-center gap-3 font-medium"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary"><Check className="h-4 w-4" /></span>{t}</li>
              ))}
            </ul>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Btn href={WINDOWS_DOWNLOAD} tone="sun"><Download className="h-5 w-5" /> Download for Windows</Btn>
              <Btn href={extensionZip.url} tone="bow" download="bob-chrome-extension.zip"><Chrome className="h-5 w-5" /> Chrome extension</Btn>
            </div>
          </div>
          <div className="relative mx-auto">
            <div className="absolute inset-4 rounded-full bg-sun/30 blur-3xl" />
            <img src={logo.url} alt="" className="animate-bob relative h-56 w-56 md:h-72 md:w-72" />
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-6 text-sm text-muted-foreground sm:flex-row">
          <div className="flex items-center gap-2"><img src={logo.url} alt="" className="h-5 w-5" /> © 2026 Bob Research Companion</div>
          <div className="flex gap-5">
            <a href={`${WEB_APP}/sign-in`} className="hover:text-foreground"><LogIn className="mr-1 inline h-4 w-4" />Log in</a>
            <a href="https://github.com/amanididier/build-bob-research-application" className="hover:text-foreground">GitHub</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
