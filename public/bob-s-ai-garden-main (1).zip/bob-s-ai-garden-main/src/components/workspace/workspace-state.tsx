import { createContext, useContext, useState, type ReactNode } from 'react';

export type Project = { id: string; name: string; description: string; tone: string; sources: number; done: number; total: number; status: string };
export type Task = { id: string; title: string; projectId: string; due: string; priority: 'High' | 'Medium' | 'Low'; completed: boolean; phase: number };
export const initialProjects: Project[] = [
  { id: 'urugendo', name: 'Urugendo', description: 'A simpler way to book intercity bus travel in Rwanda.', tone: 'yellow', sources: 7, done: 12, total: 13, status: 'In progress' },
  { id: 'stoke', name: 'Stoke-Yange', description: 'Understanding the small businesses behind a growing idea.', tone: 'blue', sources: 9, done: 5, total: 8, status: 'In progress' },
  { id: 'essay', name: 'Common App essay', description: 'Finding the story that makes an application feel personal.', tone: 'green', sources: 4, done: 5, total: 8, status: 'In progress' },
  { id: 'bob', name: 'Bob validation', description: 'Testing a more thoughtful, personal research companion.', tone: 'violet', sources: 12, done: 12, total: 15, status: 'Starting' },
];
export const initialTasks: Task[] = [
  { id: 't1', title: 'Review the passenger interview notes', projectId: 'urugendo', due: '2026-10-18', priority: 'High', completed: false, phase: 1 },
  { id: 't2', title: 'Compare booking flows from three operators', projectId: 'urugendo', due: '2026-10-19', priority: 'High', completed: false, phase: 1 },
  { id: 't3', title: 'Sketch the first mobile booking flow', projectId: 'urugendo', due: '2026-10-20', priority: 'Medium', completed: false, phase: 2 },
  { id: 't4', title: 'Outline the opening paragraph', projectId: 'essay', due: '2026-10-19', priority: 'Medium', completed: false, phase: 1 },
  { id: 't5', title: 'Collect feedback from five early users', projectId: 'bob', due: '2026-10-22', priority: 'Low', completed: false, phase: 3 },
  { id: 't6', title: 'Map the current passenger journey', projectId: 'urugendo', due: '2026-10-17', priority: 'Medium', completed: true, phase: 1 },
  { id: 't7', title: 'Save the operator pricing references', projectId: 'urugendo', due: '2026-10-16', priority: 'Low', completed: true, phase: 1 },
  { id: 't8', title: 'Define the study’s main research question', projectId: 'stoke', due: '2026-10-17', priority: 'Medium', completed: true, phase: 1 },
];
type WorkspaceState = { projects: Project[]; tasks: Task[]; activeProject: string; setActiveProject: (id: string) => void; toggleTask: (id: string) => void; addTask: (task: Omit<Task, 'id' | 'completed'>) => void; goal: string; setGoal: (goal: string) => void; goalPeriod: string; setGoalPeriod: (value: string) => void; dark: boolean; setDark: (value: boolean) => void };
const WorkspaceContext = createContext<WorkspaceState | null>(null);
export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState(initialTasks);
  const [activeProject, setActiveProject] = useState('urugendo');
  const [goal, setGoal] = useState('Finish the passenger research');
  const [goalPeriod, setGoalPeriod] = useState('Daily');
  const [dark, setDark] = useState(false);
  return <WorkspaceContext.Provider value={{ projects: initialProjects, tasks, activeProject, setActiveProject, toggleTask: (id) => setTasks((items) => items.map((task) => task.id === id ? { ...task, completed: !task.completed } : task)), addTask: (task) => setTasks((items) => [...items, { ...task, id: crypto.randomUUID(), completed: false }]), goal, setGoal, goalPeriod, setGoalPeriod, dark, setDark }}>{children}</WorkspaceContext.Provider>;
}
export function useWorkspace() { const state = useContext(WorkspaceContext); if (!state) throw new Error('WorkspaceProvider is required'); return state; }
export function dueLabel(due: string) { if (due === '2026-10-18') return 'Today'; if (due === '2026-10-19') return 'Tomorrow'; return new Date(`${due}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); }
