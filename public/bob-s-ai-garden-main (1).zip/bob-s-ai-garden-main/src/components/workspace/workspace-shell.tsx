import { Link, useRouterState } from '@tanstack/react-router';
import { useState, type ReactNode } from 'react';
import { LayoutDashboard, FileText, ListTodo, PanelLeftClose, PanelLeftOpen, Search, Moon, Sun, ChevronDown, ArrowUpRight, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import logo from '@/assets/bob-logo.png.asset.json';
import { useWorkspace } from './workspace-state';

const nav = [{ to: '/' as const, label: 'Dashboard', icon: LayoutDashboard }, { to: '/summary' as const, label: 'Summary', icon: FileText }, { to: '/tasks' as const, label: 'Tasks', icon: ListTodo }];
export function WorkspaceShell({ children, title }: { children: ReactNode; title: string }) {
  const { dark, setDark, projects, activeProject, setActiveProject } = useWorkspace();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [collapsed, setCollapsed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState('');
  return <div className={`workspace ${dark ? 'dark' : ''} ${collapsed ? 'sidebar-collapsed' : ''}`}>
    <aside className="workspace-sidebar">
      <Link to="/" className="workspace-brand"><img src={logo.url} alt="Bob" /><span>bob<span className="brand-dot">.</span></span></Link>
      <Button variant="ghost" className="sidebar-search" onClick={() => setSearchOpen(true)} title="Search projects"><Search /><span>Search projects</span><span className="search-symbol">⌕</span></Button>
      <nav aria-label="Workspace navigation">{nav.map(({ to, label, icon: Icon }) => <Button key={to} variant="ghost" asChild className={`workspace-nav ${pathname === to ? 'active' : ''}`}><Link to={to} title={label}><Icon /><span>{label}</span>{pathname === to && <span className="active-dot" />}</Link></Button>)}</nav>
      <div className="sidebar-projects"><p className="sidebar-label">YOUR PROJECTS <span>{projects.length}</span></p>{projects.map((p) => <Button key={p.id} variant="ghost" asChild className={`project-nav ${activeProject === p.id && pathname !== '/' ? 'selected' : ''}`}><Link to="/summary" onClick={() => setActiveProject(p.id)}><span className={`project-dot ${p.tone}`} /><span>{p.name}</span></Link></Button>)}</div>
      <div className="sidebar-bottom"><div className="workspace-sample"><span className="sample-dot" /> Sample workspace</div><Button variant="ghost" asChild className="download-link"><Link to="/download"><span>Get Bob</span><ArrowUpRight /></Link></Button><div className="sidebar-profile"><div className="avatar">AD</div><div><strong>Amani Didier</strong><span>Personal workspace</span></div></div></div>
    </aside>
    <div className="workspace-body"><header className="workspace-header"><div className="flex items-center gap-3"><Button variant="ghost" size="icon" onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>{collapsed ? <PanelLeftOpen /> : <PanelLeftClose />}</Button><span>{title}</span></div><div className="flex items-center gap-3"><span className="header-date">Sunday, October 18</span><Button variant="ghost" size="icon" aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'} title={dark ? 'Switch to light mode' : 'Switch to dark mode'} onClick={() => setDark(!dark)}>{dark ? <Sun /> : <Moon />}</Button><div className="avatar small">AD</div></div></header>
    <main className="workspace-main">{children}</main><footer className="workspace-footer"><span>A little progress, every day.</span><span>Bob Research Companion</span></footer></div>
    {searchOpen && <div className="workspace-search-overlay" onClick={() => setSearchOpen(false)}><section className="search-dialog" role="dialog" aria-modal="true" aria-label="Search projects" onClick={(event) => event.stopPropagation()}><div className="flex gap-2 items-center"><Search className="size-5" /><Input autoFocus placeholder="Search your projects…" aria-label="Search your projects" value={search} onChange={(event) => setSearch(event.target.value)} /><Button variant="ghost" size="icon" onClick={() => setSearchOpen(false)} aria-label="Close search"><X /></Button></div><div className="search-results">{projects.filter((p) => p.name.toLowerCase().includes(search.toLowerCase())).map((p) => <Button key={p.id} variant="ghost" asChild><Link to="/summary" onClick={() => { setActiveProject(p.id); setSearchOpen(false); }}><span className={`project-dot ${p.tone}`} />{p.name}<ArrowUpRight /></Link></Button>)}{projects.every((p) => !p.name.toLowerCase().includes(search.toLowerCase())) && <p>No projects found.</p>}</div></section></div>}
  </div>;
}
export function ProjectSelector() {
  const { projects, activeProject, setActiveProject } = useWorkspace();
  return <div className="project-selector"><span className={`project-dot ${projects.find((p) => p.id === activeProject)?.tone}`} /><select aria-label="Choose project" value={activeProject} onChange={(event) => setActiveProject(event.target.value)}>{projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select><ChevronDown className="size-4" /></div>;
}
